﻿namespace Carpintaria
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.Funcionarios = new System.Windows.Forms.ListBox();
            this.textFsalario = new System.Windows.Forms.TextBox();
            this.textFnif = new System.Windows.Forms.TextBox();
            this.textFmail = new System.Windows.Forms.TextBox();
            this.textFtel = new System.Windows.Forms.TextBox();
            this.textFmorada = new System.Windows.Forms.TextBox();
            this.textFnome = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.Clientes = new System.Windows.Forms.ListBox();
            this.textCnif = new System.Windows.Forms.TextBox();
            this.textCtel = new System.Windows.Forms.TextBox();
            this.textCmail = new System.Windows.Forms.TextBox();
            this.textCmorada = new System.Windows.Forms.TextBox();
            this.textCnome = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.Fornecedores = new System.Windows.Forms.ListBox();
            this.comboFopaga = new System.Windows.Forms.ComboBox();
            this.textFotel = new System.Windows.Forms.TextBox();
            this.textFomail = new System.Windows.Forms.TextBox();
            this.textFomorada = new System.Windows.Forms.TextBox();
            this.textFonif = new System.Windows.Forms.TextBox();
            this.textFonome = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.Artigos = new System.Windows.Forms.ListBox();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.textAdescricao = new System.Windows.Forms.TextBox();
            this.textApreco = new System.Windows.Forms.TextBox();
            this.textAquantidade = new System.Windows.Forms.TextBox();
            this.textAnome = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.Materia = new System.Windows.Forms.ListBox();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.textMpreco = new System.Windows.Forms.TextBox();
            this.textMmarca = new System.Windows.Forms.TextBox();
            this.textMcor = new System.Windows.Forms.TextBox();
            this.textMquantidade = new System.Windows.Forms.TextBox();
            this.textMtamanho = new System.Windows.Forms.TextBox();
            this.textMsecagem = new System.Windows.Forms.TextBox();
            this.textMtipo = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.EncomendaCliente = new System.Windows.Forms.ListBox();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.EncomendaFornecedor = new System.Windows.Forms.ListBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.button21 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.directorySearcher1 = new System.DirectoryServices.DirectorySearcher();
            this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1222, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Location = new System.Drawing.Point(31, 44);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1162, 379);
            this.tabControl1.TabIndex = 1;
            this.tabControl1.Tag = "";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.Funcionarios);
            this.tabPage1.Controls.Add(this.textFsalario);
            this.tabPage1.Controls.Add(this.textFnif);
            this.tabPage1.Controls.Add(this.textFmail);
            this.tabPage1.Controls.Add(this.textFtel);
            this.tabPage1.Controls.Add(this.textFmorada);
            this.tabPage1.Controls.Add(this.textFnome);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1154, 353);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Funcionarios";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(262, 294);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 15;
            this.button3.Text = "Remover";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(149, 294);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 14;
            this.button2.Text = "Editar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(43, 294);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 13;
            this.button1.Text = "Adicionar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Funcionarios
            // 
            this.Funcionarios.FormattingEnabled = true;
            this.Funcionarios.Location = new System.Drawing.Point(353, 25);
            this.Funcionarios.Name = "Funcionarios";
            this.Funcionarios.Size = new System.Drawing.Size(795, 290);
            this.Funcionarios.TabIndex = 12;
            this.Funcionarios.SelectedIndexChanged += new System.EventHandler(this.Funcionarios_SelectedIndexChanged);
            // 
            // textFsalario
            // 
            this.textFsalario.Location = new System.Drawing.Point(110, 218);
            this.textFsalario.Name = "textFsalario";
            this.textFsalario.Size = new System.Drawing.Size(195, 20);
            this.textFsalario.TabIndex = 11;
            // 
            // textFnif
            // 
            this.textFnif.Location = new System.Drawing.Point(110, 63);
            this.textFnif.Name = "textFnif";
            this.textFnif.Size = new System.Drawing.Size(195, 20);
            this.textFnif.TabIndex = 10;
            // 
            // textFmail
            // 
            this.textFmail.Location = new System.Drawing.Point(110, 100);
            this.textFmail.Name = "textFmail";
            this.textFmail.Size = new System.Drawing.Size(195, 20);
            this.textFmail.TabIndex = 9;
            // 
            // textFtel
            // 
            this.textFtel.Location = new System.Drawing.Point(110, 140);
            this.textFtel.Name = "textFtel";
            this.textFtel.Size = new System.Drawing.Size(195, 20);
            this.textFtel.TabIndex = 8;
            // 
            // textFmorada
            // 
            this.textFmorada.Location = new System.Drawing.Point(110, 181);
            this.textFmorada.Name = "textFmorada";
            this.textFmorada.Size = new System.Drawing.Size(195, 20);
            this.textFmorada.TabIndex = 7;
            // 
            // textFnome
            // 
            this.textFnome.Location = new System.Drawing.Point(110, 25);
            this.textFnome.Name = "textFnome";
            this.textFnome.Size = new System.Drawing.Size(195, 20);
            this.textFnome.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(40, 221);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Salário";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(40, 184);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Morada";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 143);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Telemóvel";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(37, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Email";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(20, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nif";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.Clientes);
            this.tabPage2.Controls.Add(this.textCnif);
            this.tabPage2.Controls.Add(this.textCtel);
            this.tabPage2.Controls.Add(this.textCmail);
            this.tabPage2.Controls.Add(this.textCmorada);
            this.tabPage2.Controls.Add(this.textCnome);
            this.tabPage2.Controls.Add(this.button6);
            this.tabPage2.Controls.Add(this.button5);
            this.tabPage2.Controls.Add(this.button4);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1154, 353);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Clientes";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // Clientes
            // 
            this.Clientes.FormattingEnabled = true;
            this.Clientes.Location = new System.Drawing.Point(307, 24);
            this.Clientes.Name = "Clientes";
            this.Clientes.Size = new System.Drawing.Size(841, 277);
            this.Clientes.TabIndex = 13;
            this.Clientes.SelectedIndexChanged += new System.EventHandler(this.Clientes_SelectedIndexChanged);
            // 
            // textCnif
            // 
            this.textCnif.Location = new System.Drawing.Point(101, 66);
            this.textCnif.Name = "textCnif";
            this.textCnif.Size = new System.Drawing.Size(181, 20);
            this.textCnif.TabIndex = 12;
            // 
            // textCtel
            // 
            this.textCtel.Location = new System.Drawing.Point(101, 100);
            this.textCtel.Name = "textCtel";
            this.textCtel.Size = new System.Drawing.Size(181, 20);
            this.textCtel.TabIndex = 11;
            // 
            // textCmail
            // 
            this.textCmail.Location = new System.Drawing.Point(101, 136);
            this.textCmail.Name = "textCmail";
            this.textCmail.Size = new System.Drawing.Size(181, 20);
            this.textCmail.TabIndex = 10;
            // 
            // textCmorada
            // 
            this.textCmorada.Location = new System.Drawing.Point(101, 179);
            this.textCmorada.Name = "textCmorada";
            this.textCmorada.Size = new System.Drawing.Size(181, 20);
            this.textCmorada.TabIndex = 9;
            // 
            // textCnome
            // 
            this.textCnome.Location = new System.Drawing.Point(101, 24);
            this.textCnome.Name = "textCnome";
            this.textCnome.Size = new System.Drawing.Size(181, 20);
            this.textCnome.TabIndex = 8;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(226, 278);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 7;
            this.button6.Text = "Remover";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(132, 278);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 6;
            this.button5.Text = "Editar";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(38, 278);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 5;
            this.button4.Text = "Adicionar";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(38, 182);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(43, 13);
            this.label11.TabIndex = 4;
            this.label11.Text = "Morada";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(35, 139);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(32, 13);
            this.label10.TabIndex = 3;
            this.label10.Text = "Email";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(35, 103);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 13);
            this.label9.TabIndex = 2;
            this.label9.Text = "Telemóvel";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(35, 69);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(20, 13);
            this.label8.TabIndex = 1;
            this.label8.Text = "Nif";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(35, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Nome";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.button9);
            this.tabPage3.Controls.Add(this.button8);
            this.tabPage3.Controls.Add(this.button7);
            this.tabPage3.Controls.Add(this.Fornecedores);
            this.tabPage3.Controls.Add(this.comboFopaga);
            this.tabPage3.Controls.Add(this.textFotel);
            this.tabPage3.Controls.Add(this.textFomail);
            this.tabPage3.Controls.Add(this.textFomorada);
            this.tabPage3.Controls.Add(this.textFonif);
            this.tabPage3.Controls.Add(this.textFonome);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1154, 353);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Fornecedores";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(253, 285);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 15;
            this.button9.Text = "Remover";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(145, 285);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 14;
            this.button8.Text = "Editar";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(37, 285);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 13;
            this.button7.Text = "Adicionar";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // Fornecedores
            // 
            this.Fornecedores.FormattingEnabled = true;
            this.Fornecedores.Location = new System.Drawing.Point(367, 18);
            this.Fornecedores.Name = "Fornecedores";
            this.Fornecedores.Size = new System.Drawing.Size(784, 290);
            this.Fornecedores.TabIndex = 12;
            this.Fornecedores.SelectedIndexChanged += new System.EventHandler(this.Fornecedores_SelectedIndexChanged);
            // 
            // comboFopaga
            // 
            this.comboFopaga.FormattingEnabled = true;
            this.comboFopaga.Items.AddRange(new object[] {
            "Multibanco",
            "Transferência",
            "Dinheiro"});
            this.comboFopaga.Location = new System.Drawing.Point(156, 214);
            this.comboFopaga.Name = "comboFopaga";
            this.comboFopaga.Size = new System.Drawing.Size(172, 21);
            this.comboFopaga.TabIndex = 11;
            // 
            // textFotel
            // 
            this.textFotel.Location = new System.Drawing.Point(156, 97);
            this.textFotel.Name = "textFotel";
            this.textFotel.Size = new System.Drawing.Size(172, 20);
            this.textFotel.TabIndex = 10;
            // 
            // textFomail
            // 
            this.textFomail.Location = new System.Drawing.Point(156, 134);
            this.textFomail.Name = "textFomail";
            this.textFomail.Size = new System.Drawing.Size(172, 20);
            this.textFomail.TabIndex = 9;
            // 
            // textFomorada
            // 
            this.textFomorada.Location = new System.Drawing.Point(156, 175);
            this.textFomorada.Name = "textFomorada";
            this.textFomorada.Size = new System.Drawing.Size(172, 20);
            this.textFomorada.TabIndex = 8;
            // 
            // textFonif
            // 
            this.textFonif.Location = new System.Drawing.Point(156, 61);
            this.textFonif.Name = "textFonif";
            this.textFonif.Size = new System.Drawing.Size(172, 20);
            this.textFonif.TabIndex = 7;
            // 
            // textFonome
            // 
            this.textFonome.Location = new System.Drawing.Point(156, 23);
            this.textFonome.Name = "textFonome";
            this.textFonome.Size = new System.Drawing.Size(172, 20);
            this.textFonome.TabIndex = 6;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(34, 217);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(100, 13);
            this.label17.TabIndex = 5;
            this.label17.Text = "Método Pagamento";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(34, 178);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(43, 13);
            this.label16.TabIndex = 4;
            this.label16.Text = "Morada";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(34, 137);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(26, 13);
            this.label15.TabIndex = 3;
            this.label15.Text = "Mail";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(34, 100);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(56, 13);
            this.label14.TabIndex = 2;
            this.label14.Text = "Telemóvel";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(34, 64);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(20, 13);
            this.label13.TabIndex = 1;
            this.label13.Text = "Nif";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(34, 26);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "Nome";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.Artigos);
            this.tabPage4.Controls.Add(this.button12);
            this.tabPage4.Controls.Add(this.button11);
            this.tabPage4.Controls.Add(this.button10);
            this.tabPage4.Controls.Add(this.textAdescricao);
            this.tabPage4.Controls.Add(this.textApreco);
            this.tabPage4.Controls.Add(this.textAquantidade);
            this.tabPage4.Controls.Add(this.textAnome);
            this.tabPage4.Controls.Add(this.label21);
            this.tabPage4.Controls.Add(this.label20);
            this.tabPage4.Controls.Add(this.label19);
            this.tabPage4.Controls.Add(this.label18);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1154, 353);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Artigos";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // Artigos
            // 
            this.Artigos.FormattingEnabled = true;
            this.Artigos.Location = new System.Drawing.Point(379, 23);
            this.Artigos.Name = "Artigos";
            this.Artigos.Size = new System.Drawing.Size(772, 277);
            this.Artigos.TabIndex = 11;
            this.Artigos.SelectedIndexChanged += new System.EventHandler(this.Artigos_SelectedIndexChanged);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(250, 263);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(84, 23);
            this.button12.TabIndex = 10;
            this.button12.Text = "Remover";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(141, 263);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 23);
            this.button11.TabIndex = 9;
            this.button11.Text = "Editar";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(46, 263);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 23);
            this.button10.TabIndex = 8;
            this.button10.Text = "Adicionar";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // textAdescricao
            // 
            this.textAdescricao.Location = new System.Drawing.Point(141, 102);
            this.textAdescricao.Name = "textAdescricao";
            this.textAdescricao.Size = new System.Drawing.Size(137, 20);
            this.textAdescricao.TabIndex = 7;
            // 
            // textApreco
            // 
            this.textApreco.Location = new System.Drawing.Point(141, 144);
            this.textApreco.Name = "textApreco";
            this.textApreco.Size = new System.Drawing.Size(137, 20);
            this.textApreco.TabIndex = 6;
            // 
            // textAquantidade
            // 
            this.textAquantidade.Location = new System.Drawing.Point(141, 60);
            this.textAquantidade.Name = "textAquantidade";
            this.textAquantidade.Size = new System.Drawing.Size(137, 20);
            this.textAquantidade.TabIndex = 5;
            // 
            // textAnome
            // 
            this.textAnome.Location = new System.Drawing.Point(141, 23);
            this.textAnome.Name = "textAnome";
            this.textAnome.Size = new System.Drawing.Size(137, 20);
            this.textAnome.TabIndex = 4;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(46, 147);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(35, 13);
            this.label21.TabIndex = 3;
            this.label21.Text = "Preço";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(43, 105);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(55, 13);
            this.label20.TabIndex = 2;
            this.label20.Text = "Descrição";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(43, 63);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(62, 13);
            this.label19.TabIndex = 1;
            this.label19.Text = "Quantidade";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(43, 26);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(35, 13);
            this.label18.TabIndex = 0;
            this.label18.Text = "Nome";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.Materia);
            this.tabPage5.Controls.Add(this.button15);
            this.tabPage5.Controls.Add(this.button14);
            this.tabPage5.Controls.Add(this.button13);
            this.tabPage5.Controls.Add(this.textMpreco);
            this.tabPage5.Controls.Add(this.textMmarca);
            this.tabPage5.Controls.Add(this.textMcor);
            this.tabPage5.Controls.Add(this.textMquantidade);
            this.tabPage5.Controls.Add(this.textMtamanho);
            this.tabPage5.Controls.Add(this.textMsecagem);
            this.tabPage5.Controls.Add(this.textMtipo);
            this.tabPage5.Controls.Add(this.label28);
            this.tabPage5.Controls.Add(this.label27);
            this.tabPage5.Controls.Add(this.label26);
            this.tabPage5.Controls.Add(this.label25);
            this.tabPage5.Controls.Add(this.label24);
            this.tabPage5.Controls.Add(this.label23);
            this.tabPage5.Controls.Add(this.label22);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1154, 353);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Matéria Prima";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // Materia
            // 
            this.Materia.FormattingEnabled = true;
            this.Materia.Location = new System.Drawing.Point(381, 34);
            this.Materia.Name = "Materia";
            this.Materia.Size = new System.Drawing.Size(770, 290);
            this.Materia.TabIndex = 17;
            this.Materia.SelectedIndexChanged += new System.EventHandler(this.Materia_SelectedIndexChanged);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(278, 300);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(75, 23);
            this.button15.TabIndex = 16;
            this.button15.Text = "Remover";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(167, 300);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(75, 23);
            this.button14.TabIndex = 15;
            this.button14.Text = "Editar";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(57, 300);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(75, 23);
            this.button13.TabIndex = 14;
            this.button13.Text = "Adicionar";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // textMpreco
            // 
            this.textMpreco.Location = new System.Drawing.Point(167, 244);
            this.textMpreco.Name = "textMpreco";
            this.textMpreco.Size = new System.Drawing.Size(186, 20);
            this.textMpreco.TabIndex = 13;
            // 
            // textMmarca
            // 
            this.textMmarca.Location = new System.Drawing.Point(167, 171);
            this.textMmarca.Name = "textMmarca";
            this.textMmarca.Size = new System.Drawing.Size(186, 20);
            this.textMmarca.TabIndex = 12;
            // 
            // textMcor
            // 
            this.textMcor.Location = new System.Drawing.Point(167, 206);
            this.textMcor.Name = "textMcor";
            this.textMcor.Size = new System.Drawing.Size(186, 20);
            this.textMcor.TabIndex = 11;
            // 
            // textMquantidade
            // 
            this.textMquantidade.Location = new System.Drawing.Point(167, 69);
            this.textMquantidade.Name = "textMquantidade";
            this.textMquantidade.Size = new System.Drawing.Size(186, 20);
            this.textMquantidade.TabIndex = 10;
            // 
            // textMtamanho
            // 
            this.textMtamanho.Location = new System.Drawing.Point(167, 103);
            this.textMtamanho.Name = "textMtamanho";
            this.textMtamanho.Size = new System.Drawing.Size(186, 20);
            this.textMtamanho.TabIndex = 9;
            // 
            // textMsecagem
            // 
            this.textMsecagem.Location = new System.Drawing.Point(167, 136);
            this.textMsecagem.Name = "textMsecagem";
            this.textMsecagem.Size = new System.Drawing.Size(186, 20);
            this.textMsecagem.TabIndex = 8;
            // 
            // textMtipo
            // 
            this.textMtipo.Location = new System.Drawing.Point(167, 34);
            this.textMtipo.Name = "textMtipo";
            this.textMtipo.Size = new System.Drawing.Size(186, 20);
            this.textMtipo.TabIndex = 7;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(54, 247);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(35, 13);
            this.label28.TabIndex = 6;
            this.label28.Text = "Preço";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(57, 209);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(23, 13);
            this.label27.TabIndex = 5;
            this.label27.Text = "Cor";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(60, 174);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(37, 13);
            this.label26.TabIndex = 4;
            this.label26.Text = "Marca";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(57, 139);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(88, 13);
            this.label25.TabIndex = 3;
            this.label25.Text = "Tempo Secagem";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(54, 106);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(52, 13);
            this.label24.TabIndex = 2;
            this.label24.Text = "Tamanho";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(57, 72);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(62, 13);
            this.label23.TabIndex = 1;
            this.label23.Text = "Quantidade";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(54, 37);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(28, 13);
            this.label22.TabIndex = 0;
            this.label22.Text = "Tipo";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.dateTimePicker2);
            this.tabPage6.Controls.Add(this.dateTimePicker1);
            this.tabPage6.Controls.Add(this.comboBox2);
            this.tabPage6.Controls.Add(this.comboBox1);
            this.tabPage6.Controls.Add(this.textBox18);
            this.tabPage6.Controls.Add(this.textBox13);
            this.tabPage6.Controls.Add(this.textBox12);
            this.tabPage6.Controls.Add(this.EncomendaCliente);
            this.tabPage6.Controls.Add(this.button18);
            this.tabPage6.Controls.Add(this.button17);
            this.tabPage6.Controls.Add(this.button16);
            this.tabPage6.Controls.Add(this.label35);
            this.tabPage6.Controls.Add(this.label34);
            this.tabPage6.Controls.Add(this.label33);
            this.tabPage6.Controls.Add(this.label32);
            this.tabPage6.Controls.Add(this.label31);
            this.tabPage6.Controls.Add(this.label30);
            this.tabPage6.Controls.Add(this.label29);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(1154, 353);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Encomendas Clientes";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(164, 91);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(173, 20);
            this.dateTimePicker2.TabIndex = 21;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(164, 61);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(173, 20);
            this.dateTimePicker1.TabIndex = 20;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Por Pagar",
            "Pago"});
            this.comboBox2.Location = new System.Drawing.Point(164, 202);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(173, 21);
            this.comboBox2.TabIndex = 19;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Por Produzir",
            "Em Produção",
            "Produzido"});
            this.comboBox1.Location = new System.Drawing.Point(164, 165);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(173, 21);
            this.comboBox1.TabIndex = 18;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(164, 237);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(173, 20);
            this.textBox18.TabIndex = 17;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(164, 126);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(173, 20);
            this.textBox13.TabIndex = 12;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(164, 25);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(173, 20);
            this.textBox12.TabIndex = 11;
            // 
            // EncomendaCliente
            // 
            this.EncomendaCliente.FormattingEnabled = true;
            this.EncomendaCliente.Location = new System.Drawing.Point(346, 22);
            this.EncomendaCliente.Name = "EncomendaCliente";
            this.EncomendaCliente.Size = new System.Drawing.Size(805, 290);
            this.EncomendaCliente.TabIndex = 10;
            this.EncomendaCliente.SelectedIndexChanged += new System.EventHandler(this.EncomendaCliente_SelectedIndexChanged);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(262, 289);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(75, 23);
            this.button18.TabIndex = 9;
            this.button18.Text = "Remove";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(155, 289);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(75, 23);
            this.button17.TabIndex = 8;
            this.button17.Text = "Editar";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(46, 289);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(75, 23);
            this.button16.TabIndex = 7;
            this.button16.Text = "Adicionar";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(46, 240);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(35, 13);
            this.label35.TabIndex = 6;
            this.label35.Text = "Preço";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(46, 202);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(112, 13);
            this.label34.TabIndex = 5;
            this.label34.Text = "Estado de Pagamento";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(43, 165);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(104, 13);
            this.label33.TabIndex = 4;
            this.label33.Text = "Estado de Produção";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(46, 129);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(55, 13);
            this.label32.TabIndex = 3;
            this.label32.Text = "Descrição";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(46, 97);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(107, 13);
            this.label31.TabIndex = 2;
            this.label31.Text = "Entrega Encomenda ";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(46, 61);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(103, 13);
            this.label30.TabIndex = 1;
            this.label30.Text = "Registo Encomenda";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(43, 28);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(55, 13);
            this.label29.TabIndex = 0;
            this.label29.Text = "Nif Cliente";
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.dateTimePicker4);
            this.tabPage7.Controls.Add(this.dateTimePicker3);
            this.tabPage7.Controls.Add(this.comboBox4);
            this.tabPage7.Controls.Add(this.comboBox3);
            this.tabPage7.Controls.Add(this.EncomendaFornecedor);
            this.tabPage7.Controls.Add(this.textBox25);
            this.tabPage7.Controls.Add(this.textBox22);
            this.tabPage7.Controls.Add(this.textBox19);
            this.tabPage7.Controls.Add(this.button21);
            this.tabPage7.Controls.Add(this.button20);
            this.tabPage7.Controls.Add(this.button19);
            this.tabPage7.Controls.Add(this.label42);
            this.tabPage7.Controls.Add(this.label41);
            this.tabPage7.Controls.Add(this.label40);
            this.tabPage7.Controls.Add(this.label39);
            this.tabPage7.Controls.Add(this.label38);
            this.tabPage7.Controls.Add(this.label37);
            this.tabPage7.Controls.Add(this.label36);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(1154, 353);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Encomendas Fornecedores";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.Location = new System.Drawing.Point(144, 89);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(177, 20);
            this.dateTimePicker4.TabIndex = 22;
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Location = new System.Drawing.Point(144, 52);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(177, 20);
            this.dateTimePicker3.TabIndex = 21;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "Pago",
            "Por Pagar"});
            this.comboBox4.Location = new System.Drawing.Point(144, 201);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(177, 21);
            this.comboBox4.TabIndex = 19;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Entrgue",
            "Por Entregar"});
            this.comboBox3.Location = new System.Drawing.Point(144, 165);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(177, 21);
            this.comboBox3.TabIndex = 18;
            // 
            // EncomendaFornecedor
            // 
            this.EncomendaFornecedor.FormattingEnabled = true;
            this.EncomendaFornecedor.Location = new System.Drawing.Point(356, 21);
            this.EncomendaFornecedor.Name = "EncomendaFornecedor";
            this.EncomendaFornecedor.Size = new System.Drawing.Size(795, 277);
            this.EncomendaFornecedor.TabIndex = 17;
            this.EncomendaFornecedor.SelectedIndexChanged += new System.EventHandler(this.EncomendaFornecedor_SelectedIndexChanged);
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(144, 235);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(177, 20);
            this.textBox25.TabIndex = 16;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(144, 128);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(177, 20);
            this.textBox22.TabIndex = 13;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(144, 21);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(177, 20);
            this.textBox19.TabIndex = 10;
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(246, 280);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(75, 23);
            this.button21.TabIndex = 9;
            this.button21.Text = "Remover";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(144, 280);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(75, 23);
            this.button20.TabIndex = 8;
            this.button20.Text = "Editar";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(46, 280);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(75, 23);
            this.button19.TabIndex = 7;
            this.button19.Text = "Adiconar";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(43, 238);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(35, 13);
            this.label42.TabIndex = 6;
            this.label42.Text = "Preço";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(40, 201);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(97, 13);
            this.label41.TabIndex = 5;
            this.label41.Text = "Estado Pagamento";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(40, 165);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(80, 13);
            this.label40.TabIndex = 4;
            this.label40.Text = "Estado Entrega";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(37, 131);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(55, 13);
            this.label39.TabIndex = 3;
            this.label39.Text = "Descrição";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(37, 95);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(104, 13);
            this.label38.TabIndex = 2;
            this.label38.Text = "Entrega Encomenda";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(37, 58);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(103, 13);
            this.label37.TabIndex = 1;
            this.label37.Text = "Registo Encomenda";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(37, 24);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(78, 13);
            this.label36.TabIndex = 0;
            this.label36.Text = "Nif Funcionário";
            // 
            // directorySearcher1
            // 
            this.directorySearcher1.ClientTimeout = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerPageTimeLimit = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerTimeLimit = System.TimeSpan.Parse("-00:00:01");
            // 
            // fileSystemWatcher1
            // 
            this.fileSystemWatcher1.EnableRaisingEvents = true;
            this.fileSystemWatcher1.SynchronizingObject = this;
            this.fileSystemWatcher1.Changed += new System.IO.FileSystemEventHandler(this.fileSystemWatcher1_Changed);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1222, 450);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox Funcionarios;
        private System.Windows.Forms.TextBox textFsalario;
        private System.Windows.Forms.TextBox textFnif;
        private System.Windows.Forms.TextBox textFmail;
        private System.Windows.Forms.TextBox textFtel;
        private System.Windows.Forms.TextBox textFmorada;
        private System.Windows.Forms.TextBox textFnome;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ListBox Clientes;
        private System.Windows.Forms.TextBox textCnif;
        private System.Windows.Forms.TextBox textCtel;
        private System.Windows.Forms.TextBox textCmail;
        private System.Windows.Forms.TextBox textCmorada;
        private System.Windows.Forms.TextBox textCnome;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboFopaga;
        private System.Windows.Forms.TextBox textFotel;
        private System.Windows.Forms.TextBox textFomail;
        private System.Windows.Forms.TextBox textFomorada;
        private System.Windows.Forms.TextBox textFonif;
        private System.Windows.Forms.TextBox textFonome;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.ListBox Fornecedores;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ListBox Artigos;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TextBox textAdescricao;
        private System.Windows.Forms.TextBox textApreco;
        private System.Windows.Forms.TextBox textAquantidade;
        private System.Windows.Forms.TextBox textAnome;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ListBox Materia;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.TextBox textMpreco;
        private System.Windows.Forms.TextBox textMmarca;
        private System.Windows.Forms.TextBox textMcor;
        private System.Windows.Forms.TextBox textMquantidade;
        private System.Windows.Forms.TextBox textMtamanho;
        private System.Windows.Forms.TextBox textMsecagem;
        private System.Windows.Forms.TextBox textMtipo;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.ListBox EncomendaCliente;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ListBox EncomendaFornecedor;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DateTimePicker dateTimePicker4;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.DirectoryServices.DirectorySearcher directorySearcher1;
        private System.IO.FileSystemWatcher fileSystemWatcher1;
    }
}

